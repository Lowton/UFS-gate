#SQLite
db = 'rpokedata.db'

#Random pokemon
limit = 7056
datedelta = 30
