#SQLite
db = 'rpokedata.db'

#Logging
logfile = 'randpok.log'

#Random pokemon
limit = 7056
datedelta = 30
